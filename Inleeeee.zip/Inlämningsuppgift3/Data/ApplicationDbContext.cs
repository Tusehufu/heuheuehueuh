﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Inlämningsuppgift3.Models;
using System.Reflection.Metadata;

namespace Inlämningsuppgift3.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Inlämningsuppgift3.Models.Product> Product { get; set; } = default!;
        public DbSet<Inlämningsuppgift3.Models.Service> Service { get; set; } = default!;
        public DbSet<Inlämningsuppgift3.Models.Category> Category { get; set; } = default!;

    }
}