﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Inlämningsuppgift3.Data.Migrations
{
    /// <inheritdoc />
    public partial class CategoryTest : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ProductViewModelId",
                table: "Category",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ProductViewModel",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false),
                    SelectedCategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductViewModel", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Category_ProductViewModelId",
                table: "Category",
                column: "ProductViewModelId");

            migrationBuilder.AddForeignKey(
                name: "FK_Category_ProductViewModel_ProductViewModelId",
                table: "Category",
                column: "ProductViewModelId",
                principalTable: "ProductViewModel",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Category_ProductViewModel_ProductViewModelId",
                table: "Category");

            migrationBuilder.DropTable(
                name: "ProductViewModel");

            migrationBuilder.DropIndex(
                name: "IX_Category_ProductViewModelId",
                table: "Category");

            migrationBuilder.DropColumn(
                name: "ProductViewModelId",
                table: "Category");
        }
    }
}
